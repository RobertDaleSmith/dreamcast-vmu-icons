To use this program you need to unzip it to the folder you want.
Then drag the VMS file you want and drop it on the file named 
"Dci_vmi.com" to convert it to a DCI file. It will ask you if it is a 
<D>ata or a <G>ame file. Pick <D>ata! Then it will ask you to name it 
give it the name you want the file to be.(only 8 char.) Next it will 
ask you if the file is copyable, pick yes. Then it will ask you 
Filename that appears in VMU directory (max = 12 chars). You must put 
"ICONDATA_VMS" or the icon will not work. Next it will ask you the VMI 
Program Description (max = 32 chars) and VMI Copyright Information 
(max = 32 chars). Put what ever you want. Then it will creat the DCI 
file. The file will be in c:\

